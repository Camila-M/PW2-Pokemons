﻿*********************************************************

*** Link de Git: https://github.com/Camila-M/PW2-Pokemons

*** DNI: 41768854

*** Nombre: Minetti Camila

*********************************************************

*** Para loguearse en la Pokedex, los datos cargados son:
*** Usuario: 'usuario'
*** Contraseña: '1234'

*********************************************************